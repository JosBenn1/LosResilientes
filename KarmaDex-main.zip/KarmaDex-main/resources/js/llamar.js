var settings = {
    "url": "https://southcentralus.api.cognitive.microsoft.com/customvision/v3.0/Prediction/53a6b6ed-1923-486d-9ea7-29d994997e63/classify/iterations/photos/url",
    "method": "POST",
    "timeout": 0,
    "headers": {
      "Prediction-Key": "a033767248e6409e8a77c37946ca629c",
      "Content-Type": "application/json"
    },
    "data": JSON.stringify({"Url":"https://exampleUrl"}),
  };
  
  $.ajax(settings).done(function (response) {
    console.log(response);
  });