<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Http;

class Controlador extends Controller
{
public function prueba(){
    $respuesta= Http:: withHeaders([
        'X-First' => 'a033767248e6409e8a77c37946ca629c',
        'X-Second' => 'application/json'
    ])->post('https://southcentralus.api.cognitive.microsoft.com/customvision/v3.0/Prediction/53a6b6ed-1923-486d-9ea7-29d994997e63/classify/iterations/photos/url',
    [
        'url' => 'https://www.animalkarma.org.mx/theme/img/bg36-5.png',
    ]);
    $predic =$respuesta->json();
    return view('prueba', compact('predic'));
        
}
}
